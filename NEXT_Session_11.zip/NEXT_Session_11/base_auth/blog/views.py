from django.shortcuts import render

# Create your views here.
from django.shortcuts import redirect, render, get_object_or_404

from .models import Comment, Post
from django.contrib.auth.decorators import login_required
from authapp.permissions import check_is_creator_or_admin

from django.utils import timezone
from django.utils.timezone import make_aware
from datetime import datetime
from functools import wraps

def home(request):
    posts = Post.objects.all()

    return render(request, "home.html", {"posts": posts})

@login_required
def new(request):
    if request.method == "POST":
        title = request.POST["title"]
        content = request.POST["content"]

        new_post = Post.objects.create(
            title=title, content=content, creator=request.user
        )
        return redirect("detail", new_post.pk)

    return render(request, "new.html")


from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone

def detail(request, post_pk):
    post = get_object_or_404(Post, pk=post_pk)

    # Update the last viewed information
    if request.user.is_authenticated:
        post.last_viewer = request.user.username
    else:
        post.last_viewer = "Anonymous"
    post.last_viewed = timezone.now()
    post.save()

    # Handle comment creation if method is POST
    if request.method == "POST":
        content = request.POST.get("content", "")
        if content:  # Ensure there's content to avoid empty comments
            Comment.objects.create(post=post, content=content, creator=request.user)
            return redirect("detail", post_pk)

    return render(request, "detail.html", {"post": post})


def update_post_details(func):
    @wraps(func)
    def wrapper(request, *args, **kwargs):
        post_pk = kwargs.get('post_pk')
        if request.method == "POST":
            last_viewed = request.POST.get('last_viewed')
            last_viewer = request.POST.get('last_viewer')

            # Update the post with new details if provided
            if last_viewed and last_viewer:
                last_viewed = make_aware(datetime.strptime(last_viewed, "%Y-%m-%dT%H:%M"))
                Post.objects.filter(pk=post_pk).update(last_viewer=last_viewer, last_viewed=last_viewed)
        
        return func(request, *args, **kwargs)
    return wrapper


@login_required
@check_is_creator_or_admin(Post, "post_pk")
@update_post_details  # Applied the new decorator
def edit(request, post_pk):
    post = Post.objects.get(pk=post_pk)

    if request.method == "POST":
        title = request.POST["title"]
        content = request.POST["content"]
        Post.objects.filter(pk=post_pk).update(title=title, content=content)
        return redirect("detail", post_pk)

    return render(request, "edit.html", {"post": post})


@login_required
@check_is_creator_or_admin(Post, "post_pk")
def delete(request, post_pk):
    post = Post.objects.get(pk=post_pk)
    post.delete()
    return redirect("home")


@login_required
@check_is_creator_or_admin(Comment, "comment_pk")
def delete_comment(request, comment_pk):
    comment = Comment.objects.get(pk=comment_pk)
    post_pk = comment.post.pk
    comment.delete()

    return redirect("detail", post_pk)


