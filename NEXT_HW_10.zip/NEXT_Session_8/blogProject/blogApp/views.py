from django.shortcuts import render, redirect, get_object_or_404
from .models import Article, Comment, Reply
from django.utils import timezone
# Create your views here.

def new(request):
    if request.method =='POST':
        print(request.POST)
        new_article = Article.objects.create(
            title = request.POST['title'],
            content = request.POST['content'],
            category = request.POST['category'],
        )
        return redirect('list')
    return render(request, 'new.html')

def list(request):
    articles = Article.objects.all()
    food_articles = Article.objects.filter(category='food')
    num_food_articles = food_articles.count()
    hobby_articles = Article.objects.filter(category='hobby')
    num_hobby_articles = hobby_articles.count()
    programming_articles = Article.objects.filter(category='programming')
    num_programming_articles = programming_articles.count()
    
    context = {
        'articles': articles,
        'num_food_articles': num_food_articles,
        'num_hobby_articles': num_hobby_articles,
        'num_programming_articles': num_programming_articles,
    }
    
    return render(request, 'list.html', context)

def detail(request, article_id):
    article = Article.objects.get(id=article_id)

    if request.method == 'POST':
        content = request.POST['content']
        Comment.objects.create(
            article=article,  # Assuming your Comment model has a field 'article' as a ForeignKey
            content=content
        )
        return redirect('detail', article_id=article_id)  # Pass the keyword argument as specified in your urls.py

    return render(request, 'detail.html', {'article': article})



def food(request):
    timezone.activate('Asia/Seoul')
    food_articles = Article.objects.filter(category='food')
    num_food_articles = food_articles.count()
    context = {
        'food_articles':food_articles,
        'num_food_articles': num_food_articles
    }
    timezone.deactivate()
    return render(request,'food.html',context)

def hobby(request):
    timezone.activate('Asia/Seoul')
    hobby_articles = Article.objects.filter(category='hobby')
    num_hobby_articles = hobby_articles.count()
    context = {
        'hobby_articles':hobby_articles,
        'num_hobby_articles': num_hobby_articles
    }
    timezone.deactivate()
    return render(request, 'hobby.html', context)

def programming(request):
    timezone.activate('Asia/Seoul')
    programming_articles = Article.objects.filter(category='programming')
    num_programming_articles = programming_articles.count()
    context = {
        'programming_articles':programming_articles,
        'num_programming_articles': num_programming_articles
    }
    timezone.deactivate()
    return render(request, 'programming.html', context)

def delete_comment(request, article_id, comment_id):
    comment = Comment.objects.get(id=comment_id)
    comment.delete()
    return redirect('detail', article_id)

def base(request):
    return render(request,'base.html')

def post_reply(request, comment_id):
    if request.method == "POST":
        content = request.POST.get('content')
        if content:  # Simple validation to check if content is not empty
            comment = get_object_or_404(Comment, id=comment_id)
            Reply.objects.create(comment=comment, content=content)
            return redirect('detail', article_id=comment.article.id)  # Adjust redirect as necessary
    # If not POST or content is empty, redirect or show an error
    return redirect('detail')