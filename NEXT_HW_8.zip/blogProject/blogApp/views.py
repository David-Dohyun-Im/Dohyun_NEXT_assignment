from django.shortcuts import render, redirect
from .models import Article
from django.utils import timezone
# Create your views here.

def new(request):
    if request.method =='POST':
        print(request.POST)
        new_article = Article.objects.create(
            title = request.POST['title'],
            content = request.POST['content'],
            category = request.POST['category'],
        )
        return redirect('list')
    return render(request, 'new.html')

def list(request):
    articles = Article.objects.all()
    food_articles = Article.objects.filter(category='food')
    num_food_articles = food_articles.count()
    hobby_articles = Article.objects.filter(category='hobby')
    num_hobby_articles = hobby_articles.count()
    programming_articles = Article.objects.filter(category='programming')
    num_programming_articles = programming_articles.count()
    
    context = {
        'articles': articles,
        'num_food_articles': num_food_articles,
        'num_hobby_articles': num_hobby_articles,
        'num_programming_articles': num_programming_articles,
    }
    
    return render(request, 'list.html', context)

def detail(request, article_id):
    article = Article.objects.get(id = article_id)
    return render(request, 'detail.html', {'article':article})



def food(request):
    timezone.activate('Asia/Seoul')
    food_articles = Article.objects.filter(category='food')
    num_food_articles = food_articles.count()
    context = {
        'food_articles':food_articles,
        'num_food_articles': num_food_articles
    }
    timezone.deactivate()
    return render(request,'food.html',context)

def hobby(request):
    timezone.activate('Asia/Seoul')
    hobby_articles = Article.objects.filter(category='hobby')
    num_hobby_articles = hobby_articles.count()
    context = {
        'hobby_articles':hobby_articles,
        'num_hobby_articles': num_hobby_articles
    }
    timezone.deactivate()
    return render(request, 'hobby.html', context)

def programming(request):
    timezone.activate('Asia/Seoul')
    programming_articles = Article.objects.filter(category='programming')
    num_programming_articles = programming_articles.count()
    context = {
        'programming_articles':programming_articles,
        'num_programming_articles': num_programming_articles
    }
    timezone.deactivate()
    return render(request, 'programming.html', context)
