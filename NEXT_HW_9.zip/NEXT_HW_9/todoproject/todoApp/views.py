from django.shortcuts import render, redirect
from .models import TodoItem
from datetime import date

def home(request):
    todos = TodoItem.objects.order_by('deadline')  # Get all todo items
    for todo in todos:
        d_day = (todo.deadline - date.today()).days
        todo.d_day = d_day  # Adding a d_day attribute to each todo item
    return render(request, 'home.html', {'todos': todos})


def new(request):
    if request.method == 'POST':
        todoitem = TodoItem.objects.create( title = request.POST['title'],
        content = request.POST['content'],
        deadline = request.POST['deadline']
        )
        return redirect('detail', todoitem.pk) 
    return render(request, 'new.html')

def detail(request, post_pk):
    todoitem = TodoItem.objects.get(pk=post_pk)
    return render(request, 'detail.html', {'todoitem': todoitem})

def update(request, post_pk):
    todoitem = TodoItem.objects.get(pk=post_pk)

    if request.method == 'POST': 
        TodoItem.objects.filter(pk=post_pk).update(
            title = request.POST['title'],
            content = request.POST['content'],
            deadline = request.POST['deadline']
        )
        return redirect('detail', post_pk)
    return render(request, 'update.html', {'todoitem': todoitem})

def delete(request, post_pk):
    todoitem = TodoItem.objects.get(pk=post_pk)
    todoitem.delete()
    return redirect('home')